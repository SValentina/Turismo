$.ajax({
    type: "GET",
    url: "getEventos",
    success: function (data) {
        let eventos = JSON.parse(data);
        let template='<option>Seleccione un evento </option>';
        eventos.forEach(evento =>{   
            template+= "<option value="+evento.id+">"+evento.nombre+"</option>";                        
        });
        $('#evento_id').html(template);   
    }
});

var latitudes = new Array();
var longitudes = new Array();
//Función para consultar por fecha          
function buscar(){                
    $.ajax({
        type: "POST",
        url: "buscarPermisos",
        data: {fecha_evento:$('#fecha_evento').val(), evento_id:$('#evento_id').val()},       
        async: false,  //para poder cargar los valores en los arrays                                        
        success: function (data){                                
            let template='';
            if (data.localeCompare("[]")){ 
                let permisos = JSON.parse(data);                     
                template = `<div class="card" id="map">
                                <script src="https://maps.googleapis.com/maps/api/js?key=&callback=initMap&libraries=&v=weekly" async>
                                </div>`;                                            
                permisos.forEach(permiso =>{   
                    latitudes.push(parseFloat(permiso['domicilio'].latLocalidad));
                    longitudes.push(parseFloat(permiso['domicilio'].longLocalidad));                        
                });     
            }
            else 
                template+= "<div class='card' id='no-reservas'><b>No hay reservas.</b></div>";               
            $('#contenedor-mapa').html(template);  
        }                    
    });                               
}            

function initMap() {
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 4,
        center: { lat: -36.61828979857, lng: -64.2916770389461 },
    });

    let tourStops = [];
    for(let j=0; j<latitudes.length; j++)
        tourStops.push({ lat: latitudes[j], lng: longitudes[j]});

    // Create an info window to share between markers.
    const infoWindow = new google.maps.InfoWindow();
    // Create the markers.
    tourStops.forEach((position, i) => {
        const marker = new google.maps.Marker({
            position,
            map,
            optimized: false,
        });
        // Add a click listener for each marker, and set up the info window.
        marker.addListener("click", () => {
            infoWindow.close();
            infoWindow.open(marker.getMap(), marker);
        });
    });
}