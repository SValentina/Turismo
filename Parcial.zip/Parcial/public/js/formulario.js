//Cargo en el select de eventos los valores de la base de datos
$.ajax({
    type: "GET",
    url: "getEventos",
    success: function (data) {
        let eventos = JSON.parse(data);
        let template='<option>Seleccione un evento </option>';
        eventos.forEach(evento =>{   
            template+= "<option value="+evento.id+">"+evento.nombre+"</option>";                        
        });
        $('#evento_id').html(template);   
    }
});


//Consulta a la api y trae todos los departamentos de la provincia consultada
var provincia = document.getElementById('idProvincia');
provincia.addEventListener('change',
    function(){
        var idProvincia = this.options[provincia.selectedIndex].value;           
        $.ajax({
            type: "GET",
            url: "https://apis.datos.gob.ar/georef/api/departamentos?provincia="+idProvincia+"&orden=nombre&max=100",
            success: function (data) {
                var departamentos = data.departamentos;
                let template='<option>Seleccione un departamento</option>';
                departamentos.forEach(depto =>{   
                    template+= "<option value="+depto.id+">"+depto.nombre+"</option>";                        
                });
                $('#idDepartamento').html(template);   
            }
        })
    });

//Consulta a la api y trae todas las localidades del departamento consultado
var departamento = document.getElementById('idDepartamento');
departamento.addEventListener('change',
    function(){          
        var idDepartamento = this.options[departamento.selectedIndex].value;           
        $.ajax({
            type: "GET",
            url: "https://apis.datos.gob.ar/georef/api/localidades-censales?provincia="+provincia.value+"&departamento="+idDepartamento+"&orden=nombre&max=100",
            success: function (data) {                                        
                var localidades = data.localidades_censales;                    
                let template='<option>Seleccione una localidad</option>';
                localidades.forEach(localidad =>{   
                    template+= "<option value="+localidad.id+">"+localidad.nombre+"</option>";
                });
                $('#idLocalidad').html(template);   
            }
        })
    });

//Consulta a la api de acuerdo a la localidad seleccionada y crea dos input hidden con la latitud y longitud.
var localidad = document.getElementById('idLocalidad');
localidad.addEventListener('change',
    function(){          
        var idLocalidad = this.options[localidad.selectedIndex].value;           
        $.ajax({
            type: "GET",
            url: "https://apis.datos.gob.ar/georef/api/localidades-censales?id="+idLocalidad,
            success: function (data) {                                        
                var puntos = data.localidades_censales[0].centroide;                                                    
                let template = "<input type='hidden' value="+puntos.lat+" name='latLocalidad'>"+
                                "<input type='hidden' value="+puntos.lon+" name='longLocalidad'>";

                $('#puntos').html(template);   
            }
        })
    });

var ids = new Array();
function getPosts(e){
    e.preventDefault();
};

//Lo utilizo para que no se recargue la página y permita la visualización del iframe.
$('#boton').on('click', function(e){
    e.preventDefault();
    post("setCiudadano");       
    post("setDomicilio");             
    permisos(ids);  //envío los ids de los objetos creados
});

//Función que realiza un post dado un URL e inserta el id del objeto creado en un array global.
function post(URL) {   
    $.ajax({
        type: "POST",
        url: URL,            
        data: $('#formulario').serialize(),
        async: false,  //para poder devolver los valores hacia la función getPosts                    
        success: function (data) {              
            let respuesta = JSON.parse(data);
            ids.push(respuesta['id']);             
        }
    });      
    return false;
}

//Función que genera un permiso con los ids de los objetos ingresados anteriormente.
function permisos($ids){
    $.ajax({
        type: "POST",
        url: "setPermiso",            
        data: {ciudadano_id: $ids[0], domicilio_id: $ids[1], evento_id:$('#evento_id').val(), 
                fecha_evento:$('#fecha_evento').val()},                       
        success: function(data){
            let respuesta = JSON.parse(data);                  
            //Almaceno los datos para el comprobante por medio de localStorage
            localStorage.setItem("codigoPermiso", respuesta['codigoPermiso']);
            localStorage.setItem("nombre", $('#nombre').val());
            localStorage.setItem("apellido", $('#apellido').val());
            localStorage.setItem("cuil", $('#cuil').val());                                                
            
            $('#frame').html($('<iframe width="450px" height="460px"/>').attr('src', 'comprobante'));                
            $('#myModal').modal('show'); // abrir                              
        },             
        error: function () {
            alert("Error. Complete los campos obligatorios.");
        }            
    });   
    return false;
}
