<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Linea para ejecutar las rutas en laravel v8
Route::namespace("App\\Http\\Controllers")->group(function () {
    Route::post('setEvento', 'EventoController@store');
    Route::get('getEventos', 'EventoController@show');
    Route::post('setCiudadano', 'CiudadanoController@store');
    Route::post('setDomicilio', 'DomicilioController@store');
    Route::post('setPermiso', 'PermisoController@store');
    Route::get('form', 'HomeController@index');
    Route::get('admin', 'PermisoController@show');
    Route::post('buscarPermisos', 'PermisoController@buscarPermisos');
    Route::get('comprobante', function () {
        return view('comprobante');
    });
});