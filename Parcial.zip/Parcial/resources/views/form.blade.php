<!DOCTYPE html>

<html>
    <head>
        <title>Permiso de Turismo Interno</title>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">                    

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>      
          
        <link rel="stylesheet" href="{{ asset('/css/formulario.css') }}" type="text/css">  
        
        <nav>
            <img src="https://permisoturismo.lapampa.gob.ar/img/logoTurismo.png" alt="Logo de La Pampa Turismo">
        </nav>
    </head>    

    <body>
        
        <div class="arriba">            
        </div>
        <div class="container" id="container-principal">            
            <div class="card">
                <form id="formulario">                         
                    <div class="container" id="container-sec">
                        <p id="informacion">
                            Ingrese los datos para solicitar el Certificado de Turismo Interno <br>o Reimprimirlo.
                            <p id="obligatorio">(*) Campos obligatorios.</p>
                        </p>                        
                        <p id="titulo"><i class="fa fa-user"></i> DATOS PERSONALES</p>
                        
                        <div class="row align-items-center">
                            <div class="col">                            
                                <label>DNI *</label><br>                                                        
                                <input type="text" name="nroDoc" required="required">                            
                            </div>
                            <div class="col" >
                                <label>N° de Trámite *</label><br>
                                <input type="text" name="nroTramite" required="required">
                            </div>
                            <div class="col-4">
                                <!--Consideré que es requerido ya que por medio de este se 
                                    determina si existe el usuario o no en la tabla-->
                                <label>Cuil *</label><br>
                                <input type="text" name="cuil" id="cuil" required="required">
                            </div>
                        </div>
                        <hr>
                        <div class="row align-items-center">
                            <div class="col">
                                <label>Nombre *</label><br>
                                <input type="text" name="nombre" id="nombre" required="required">
                            </div>
                            <div class="col">
                                <label>Apellido *</label><br>
                                <input type="text" name="apellido" id="apellido" required="required">
                            </div>
                        </div>
                        <div class="row align-items-center">
                            <div class="col">
                                <label>Celular</label><br>
                                <input type="text" name="telefono">
                            </div>                        
                            <div class="col">
                                <label>Género</label><br>
                                <select name="sexo">
                                    <option value="Masculino">Masculino</option>
                                    <option value="Femenino">Femenino</option>            
                                    <option value="Otro">Otro</option>   
                                </select>
                            </div>
                            <div class="col">
                                <label>Extranjero</label><br>
                                <select name="extranjero">
                                    <option value="1">Si</option>
                                    <option value="0">No</option>                        
                                </select>
                            </div>
                        </div>
                        <div class="row align-items-center">
                            <div class="col-6">
                                <label>E-mail</label><br>
                                <input type="text" name="email">
                            </div>
                        </div>
                    </div>
                    
                    <div class="container" id="container-sec">
                        <p id="titulo"><i class="fa fa-calendar-check-o"></i> DESTINO</p>                    
                        <div class="row align-items-center">
                            <div class="col">
                                <label>Evento *</label><br>
                                <select name="evento_id" id="evento_id">                                                                                                                            
                                </select>                                
                            </div>
                            <div class="col">
                                <label>Fecha del evento *</label><br>
                                <input type="date" id="fecha_evento" required="required">
                            </div>       
                        </div>                     
                    </div>
                    
                    
                    <div class="container" id="container-sec">
                        <p id="titulo"><i class="fa fa-map-marker"></i> UBICACION ACTUAL</p>
                        <div class="row align-items-center">
                            <div class="col">
                                <label>Provincia *</label><br>
                                <select id="idProvincia" name="idProvincia">
                                    @foreach ($provincias['provincias'] as $provincia)
                                        <option value={{$provincia['id']}}>{{$provincia['nombre']}}</option>
                                    @endforeach  
                                </select>
                            </div>
                            
                            <div class="col">
                                <label>Departamento *</label><br>
                                <select id="idDepartamento" name="idDepartamento">
                                    <option>Seleccione un departamento</option>
                                </select>
                            </div>
                            <div class="col">
                                <label>Localidad *</label><br>
                                <select id="idLocalidad" name="idLocalidad" >
                                    <option>Seleccione una localidad</option>
                                </select>
                            </div>
                            <div id="puntos">
                            </div>
                        </div>
                        <div class="row align-items-center">                        
                            <div class="col">
                                <label>Calle</label><br>
                                <input type="text" name="calle">
                            </div>
                            <div class="col-2">
                                <label>Número</label><br>
                                <input type="text" name="nro">
                            </div>
                            <div class="col-2">
                                <label>Piso</label><br>
                                <input type="text" name="piso">
                            </div>
                            <div class="col-2">
                                <label>Depto</label><br>
                                <input type="text" name="depto">
                            </div>                                                
                        </div>            
                        <div id="container-sec">
                            <div class="row align-items-center">
                                <button id="boton" onclick="getPosts(event)">REGISTRARSE</button>                              
                            </div>
                        </div>
                    </div>                
                </form>                           
            </div>                                                                            
        </div>

        <!-- The Modal -->
        <div class="modal" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">      
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Comprobante</h4>
                        <button type="button" class="close" onClick="window.location.reload();" data-dismiss="modal">&times;</button>
                    </div>        
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div id="frame">                            
                        </div>                    
                    </div>        
                    <!-- Modal footer -->
                    <div class="modal-footer">                        
                    </div>                    
                </div>
            </div>
        </div>
  
        <div id="footer">
            Primer Examen Parcial — Mayo 2021<br>
            Tema 2<br>
            Scovenna Valentina
        </div>                  
    </body>
    <script src="{{ asset('/js/formulario.js') }}" type="text/javascript"></script>
</html>
