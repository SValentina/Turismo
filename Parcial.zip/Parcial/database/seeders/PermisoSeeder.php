<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class PermisoSeeder extends Seeder
{    
    // Run the database seeds.
    public function run()
    {
        DB::table('permisos')->insert([
            'ciudadano_id' => 1,
            'evento_id' => 3,            
            'domicilio_id' => 1,
            'fecha_creacion' => "2021-06-03",
            'fecha_evento' => "2021-06-30",
        ]);

        DB::table('permisos')->insert([
            'ciudadano_id' => 2,
            'evento_id' => 2,            
            'domicilio_id' => 2,
            'fecha_creacion' => "2021-06-03",
            'fecha_evento' => "2021-06-19",
        ]);

        DB::table('permisos')->insert([
            'ciudadano_id' => 3,
            'evento_id' => 5,            
            'domicilio_id' => 3,
            'fecha_creacion' => "2021-06-03",
            'fecha_evento' => "2021-07-09",
        ]);
    }
}
