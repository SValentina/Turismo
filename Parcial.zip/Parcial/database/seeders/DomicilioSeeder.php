<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class DomicilioSeeder extends Seeder
{
    // Run the database seeds.
    public function run()
    {        
        DB::table('domicilios')->insert([
            'idProvincia' => 42,
            'idDepartamento' => 42021,            
            'idLocalidad' => 42021010,
            'calle' => "Av San Martín",
            'nro' => 380,
            'depto' => 0,
            'piso' => 0,
            'latLocalidad' => "-36.527922625355",
            'longLocalidad' => "-64.0105558979729",
        ]);

        DB::table('domicilios')->insert([
            'idProvincia' => 42,
            'idDepartamento' => 42105,            
            'idLocalidad' => 42105030,
            'calle' => "29",
            'nro' => 1740,
            'depto' => 1,
            'piso' => 2,
            'latLocalidad' => "-35.6633805937206",
            'longLocalidad' => "-63.760929267739",
        ]);

        DB::table('domicilios')->insert([
            'idProvincia' => 62,
            'idDepartamento' => 62007,            
            'idLocalidad' => 62007090,
            'calle' => "España",
            'nro' => 599,
            'depto' => 2,
            'piso' => 5,
            'latLocalidad' => "-40.8093232712389",
            'longLocalidad' => "-62.9853203682712",
        ]);
    }
}
