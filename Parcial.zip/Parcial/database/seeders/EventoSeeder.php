<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class EventoSeeder extends Seeder
{
    // Run the database seeds.
    public function run()
    {
        DB::table('eventos')->insert([
            'nombre' => "Reserva Provincial Parque Luro",
        ]);
        DB::table('eventos')->insert([
            'nombre' => "Colonia Menonita",
        ]);
        DB::table('eventos')->insert([
            'nombre' => "Parque Nacional Lihuel Calel",
        ]);
        DB::table('eventos')->insert([
            'nombre' => "Museo Atelier Antonio Ortiz Echagüe",
        ]);
        DB::table('eventos')->insert([
            'nombre' => "Casa de Piedra",
        ]);
        DB::table('eventos')->insert([
            'nombre' => "Parque Indígena Leubuco",
        ]);
    }
}
