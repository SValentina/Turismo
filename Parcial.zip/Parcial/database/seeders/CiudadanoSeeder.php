<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class CiudadanoSeeder extends Seeder
{    
    // Run the database seeds.
    public function run()
    {
        DB::table('ciudadanos')->insert([
            'nombre' => "Valentina",
            'apellido' => "Scovenna",            
            'nroDoc' => "39932727",
            'cuil' => "27399327275",
            'nroTramite' => 54730126,
            'email' => "vscovenna@hotmail.com",
            'telefono' => 2954478390,
            'sexo' => "Femenino",
            'extranjero' => 0,
        ]);

        DB::table('ciudadanos')->insert([
            'nombre' => "Marta",
            'apellido' => "Sanchez",            
            'nroDoc' => "23184475",
            'cuil' => "27231844752",
            'nroTramite' => 1547632,            
            'telefono' => 2302487015,
            'sexo' => "Femenino",
            'extranjero' => 0,
        ]);

        DB::table('ciudadanos')->insert([
            'nombre' => "Julio",
            'apellido' => "Sales",            
            'nroDoc' => "35760120",
            'cuil' => "23357601200",
            'nroTramite' => 578460121,
            'email' => "jsales@hotmail.com",
            'telefono' => 2920400123,
            'sexo' => "Masculino",
            'extranjero' => 0,
        ]);
    }
}
