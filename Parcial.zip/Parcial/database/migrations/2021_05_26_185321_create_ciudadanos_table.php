<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCiudadanosTable extends Migration
{    
    //Run the migrations.    
    public function up()
    {
        Schema::create('ciudadanos', function (Blueprint $table) {
            $table->increments('id');
            //Consideré que no puede ser nulo ya que por medio de este se determina si existe el usuario o no en la tabla
            $table->string('cuil'); 
            $table->string('nombre');
            $table->string('apellido');
            $table->string('nroDoc');
            $table->unsignedInteger('nroTramite');
            $table->unsignedInteger('telefono')->nullable();
            $table->string('email')->nullable();
            $table->boolean('extranjero')->nullable();
            $table->string('sexo')->nullable();
        });
    }
    
    // Reverse the migrations.
    public function down()
    {
        Schema::dropIfExists('ciudadanos');
    }
}
