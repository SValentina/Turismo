<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDomiciliosTable extends Migration
{    
    // Run the migrations.    
    public function up()
    {
        Schema::create('domicilios', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('idProvincia');
            $table->integer('idDepartamento');
            $table->integer('idLocalidad');
            $table->string('calle')->nullable();
            $table->unsignedInteger('nro')->nullable();
            $table->integer('piso')->nullable();
            $table->integer('depto')->nullable();
            $table->string('latLocalidad');
            $table->string('longLocalidad');
        });
    }

 
    // Reverse the migrations.     
    public function down()
    {
        Schema::dropIfExists('domicilios');
    }
}
