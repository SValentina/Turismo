<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePermisosTable extends Migration
{    
    // Run the migrations.     
    public function up()
    {
        Schema::create('permisos', function (Blueprint $table) {            
            $table->increments('codigoPermiso');
            $table->unsignedInteger('ciudadano_id');            
            $table->unsignedInteger('evento_id');
            $table->unsignedInteger('domicilio_id');                        
            $table->date('fecha_creacion');   
            $table->date('fecha_evento');          
        });

        DB::statement("ALTER TABLE permisos AUTO_INCREMENT=100000");
    }
    
    // Reverse the migrations. 
    public function down()
    {
        Schema::dropIfExists('permisos');
    }
}
