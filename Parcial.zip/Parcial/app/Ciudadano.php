<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ciudadano extends Model
{
    protected $fillable = ['cuil', 'nombre', 'apellido', 'nroDoc', 'nroTramite', 'telefono', 'email', 'extranjero', 'sexo'];
    public $timestamps = false;

    public function permisos()
    {
        return $this->hasMany(Permiso::class);
    }
}
