<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Domicilio extends Model
{
    protected $fillable = ['idProvincia', 'idDepartamento', 'idLocalidad', 'calle', 'nro', 'piso', 'depto', 'latLocalidad', 'longLocalidad'];
    public $timestamps = false;

    public function permisos()
    {
        return $this->hasMany(Permiso::class);
    }
}
