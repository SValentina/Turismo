<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PermisoResource extends JsonResource
{    
    // Transform the resource into an array.    
    public function toArray($request)
    {
        return [            
            'codigoPermiso' => $this->id,
            'fecha_creacion' => $this->fecha_creacion,                       
            'fecha_evento' => $this->fecha_evento,
            'evento' => new EventoResource($this->evento),
            'ciudadano' => new CiudadanoResource($this->ciudadano),
            'domicilio' => new DomicilioResource($this->domicilio),            
        ];
    }
}
