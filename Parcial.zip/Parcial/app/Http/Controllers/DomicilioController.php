<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Domicilio;
use App\Http\Resources\DomicilioResource;

class DomicilioController extends Controller
{
    public function store(Request $request)
    {        
        $domicilio = Domicilio::create([
            'idProvincia' => $request->input('idProvincia'),
            'idDepartamento' => $request->input('idDepartamento'),
            'idLocalidad' => $request->input('idLocalidad'),
            'calle' => $request->input('calle'),
            'nro' => $request->input('nro'),
            'piso' => $request->input('piso'),
            'depto' => $request->input('depto'),
            'latLocalidad' => $request->input('latLocalidad'),
            'longLocalidad' => $request->input('longLocalidad'),
        ]);
        $respuesta = new DomicilioResource($domicilio);
        
        return $respuesta->toJson();
    }
}
