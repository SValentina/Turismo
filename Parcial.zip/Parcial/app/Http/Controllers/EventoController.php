<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Evento;
use App\Http\Resources\EventoResource; 

class EventoController extends Controller
{
    public function store(Request $request)
    {        
        $evento = Evento::create([
            'nombre' => $request->input('nombre_evento'),                              
        ]);
        $respuesta = new EventoResource($evento);
        
        return $respuesta->toJson();
    }

    public function show(){
        $eventos = Evento::orderBy('nombre', 'asc')->get();
        $respuesta = EventoResource::collection($eventos)->toJson();

        return $respuesta; 
    }
}
