<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Permiso;
use App\Http\Resources\PermisoResource;

class PermisoController extends Controller
{
    public function store(Request $request)
    {        
                    
        $permiso = Permiso::create([
            'ciudadano_id' => $request->input('ciudadano_id'),
            'evento_id' => $request->input('evento_id'),
            'domicilio_id' => $request->input('domicilio_id'),
            'fecha_creacion' => date('Y-m-d'), 
            'fecha_evento' => $request->input('fecha_evento'),                               
        ]);  
        $respuesta = new PermisoResource($permiso);

        return $respuesta->toJson();      
    }

    //muestra todos los permisos que hay en la base de datos
    public function show()
    {
        $permisos = PermisoResource::collection(Permiso::all()); //paginar   
        $hoy = Permiso::where("fecha_creacion", date('Y-m-d'))->get();       
        return view ('admin', compact('permisos', 'hoy'));
    }

    // busca permisos de acuerdo a una fecha dada
    public function buscarPermisos(Request $request)
    {        
        $respuesta = Permiso::where("fecha_evento", $request->input('fecha_evento'))
                    ->where("evento_id", $request->input('evento_id'))
                    ->get();
        $permisos = PermisoResource::collection($respuesta)->toJson();
        
        return $permisos;
    }

}
