<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Http;

class HomeController extends Controller
{
    public function index()
    {
        $response = Http::get('https://apis.datos.gob.ar/georef/api/provincias?orden=nombre&max=24');
        $provincias = $response->json();        
    
        return view('form', compact('provincias'));
    }
}
