<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ciudadano;
use App\Http\Resources\CiudadanoResource;

class CiudadanoController extends Controller
{
    public function store(Request $request)
    {       
        $ciudadano_buscado = Ciudadano::where("cuil", $request->input('cuil'))->get();
        $respuesta = $ciudadano_buscado->toJson();
        $existe = 0;
        if (strcmp($respuesta, "[]"))    //si existe devuelve 1
            $existe = 1;  

        if(!$existe){         
            $ciudadano = Ciudadano::create([                     
                'cuil' => $request->input('cuil'),
                'nombre' => $request->input('nombre'),
                'apellido' => $request->input('apellido'),
                'nroDoc' => $request->input('nroDoc'),
                'nroTramite' => $request->input('nroTramite'),
                'telefono' => $request->input('telefono'),
                'email' => $request->input('email'),
                'extranjero' => $request->input('extranjero'),
                'sexo' => $request->input('sexo'),
            ]);        
            $respuesta = new CiudadanoResource($ciudadano);            
        }
        else
            //Devuelvo el ciudadano ya cargado para utilizar su id
            $respuesta = new CiudadanoResource($ciudadano_buscado->get(0));
    
        return $respuesta->toJson();  
    }

    //Busco un ciudadano por cuil para realizar un control en la creación de los mismos.
    public function buscarPorCuil($cuil)
    {                
        
        
        return $existe; 
    }
}