<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Evento extends Model
{
    protected $fillable = ['nombre'];
    public $timestamps = false;

    public function permisos()
    {
        return $this->hasMany(Permiso::class);
    }
}
