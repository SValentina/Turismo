<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Permiso extends Model
{
    protected $fillable = ['ciudadano_id', 'evento_id', 'domicilio_id', 'fecha_creacion', 'fecha_evento'];
    public $timestamps = false;

    public function ciudadano()
    {
        return $this->belongsTo(Ciudadano::class);
    }

    public function domicilio()
    {
        return $this->belongsTo(Domicilio::class);
    }

    public function evento()
    {
        return $this->belongsTo(Evento::class);
    }
}
