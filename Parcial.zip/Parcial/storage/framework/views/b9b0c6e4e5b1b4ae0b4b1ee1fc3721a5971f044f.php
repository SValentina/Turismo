<!DOCTYPE html>

<html>
    <head>
        <title>Formulario</title>
 
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">            
        <meta name="token" content="<?php echo e(csrf_token()); ?>">
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>           
        <!--<script src="<?php echo e(asset('/js/bootstrap.js')); ?>" type="text/javascript"></script>    -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">                
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>" type="text/css">  

        <nav>
            <img src="https://permisoturismo.lapampa.gob.ar/img/logoTurismo.png" alt="Logo de La Pampa Turismo">
        </nav>
    </head>    

    <body>
        
        <div class="arriba">            
        </div>
        <div class="container" id="container-principal">            
            <div class="card">
                <div class="alert-success"> 
                    Creado
                </div>
                <?php if(session('permisoCreado')): ?>
                    <span></span>
                    <div class="alert-success form-control"> <?php echo e(session('permisoCreado')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('permisoNoCreado')): ?>
                    <span></span>
                    <div class="alert-danger form-control"> <?php echo e(session('permisoNoCreado')); ?></div>
                <?php endif; ?> 
                <form id="formulario">
                    <?php echo csrf_field(); ?>     
                    <div class="container" id="container-sec">
                        <p id="informacion">
                            Ingrese los datos para solicitar el Certificado de Turismo Interno <br>o Reimprimirlo.
                        </p>
                        <p id="titulo"><i class="fa fa-user"></i> DATOS PERSONALES</p>

                        <!-- AGREGAR CUIL Y NUMERO DE TRAMITE-->
                        <div class="row align-items-center">
                            <div class="col">
                                <label>DNI</label><br>                        
                                <input type="text" name="nroDoc">                            
                            </div>
                            <div class="col" >
                                <label>N° de Trámite</label><br>
                                <input type="text" name="nroTramite">
                            </div>
                            <div class="col-4">
                                <label>Cuil</label><br>
                                <input type="text" name="cuil">
                            </div>
                        </div>
                        <hr>
                        <div class="row align-items-center">
                            <div class="col">
                                <label>Nombre</label><br>
                                <input type="text" name="nombre">
                            </div>
                            <div class="col">
                                <label>Apellido</label><br>
                                <input type="text" name="apellido">
                            </div>
                        </div>
                        <div class="row align-items-center">
                            <div class="col">
                                <label>Celular</label><br>
                                <!--<input type="text">-->
                            </div>                        
                            <div class="col">
                                <label>Género</label><br>
                                <select name="sexo">
                                    <option value="Masculino">Masculino</option>
                                    <option value="Femenino">Femenino</option>            
                                    <option value="Otro">Otro</option>   
                                </select>
                            </div>
                            <div class="col">
                                <label>Extranjero</label><br>
                                <select name="extranjero">
                                    <option value="1">Si</option>
                                    <option value="0">No</option>                        
                                </select>
                            </div>
                        </div>
                        <div class="row align-items-center">
                            <div class="col-6">
                                <label>E-mail</label><br>
                                <input type="text" name="email">
                            </div>
                        </div>
                    </div>
                    
                    <div class="container" id="container-sec">
                        <p id="titulo"><i class="fa fa-calendar-check-o"></i> DESTINO</p>                    
                        <div class="row align-items-center">
                            <div class="col">
                                <label>Evento</label><br>
                                <input type="text" name="nombre_evento">
                            </div>
                            <div class="col">
                                <label>Fecha de ingreso</label><br>
                                <input type="date" id="fecha">
                            </div>       
                        </div>                     
                    </div>
                    
                    
                    <div class="container" id="container-sec">
                        <p id="titulo"><i class="fa fa-map-marker"></i> UBICACION ACTUAL</p>
                        <div class="row align-items-center">
                            <div class="col">
                                <label>Provincia</label><br>
                                <select id="idProvincia" name="idProvincia">
                                    <?php $__currentLoopData = $provincias['provincias']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=<?php echo e($provincia['id']); ?>><?php echo e($provincia['nombre']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                </select>
                            </div>
                            
                            <div class="col">
                                <label>Departamento</label><br>
                                <select id="idDepartamento" name="idDepartamento">
                                    <option>Seleccione un departamento</option>
                                </select>
                            </div>
                            <div class="col">
                                <label>Localidad</label><br>
                                <select id="idLocalidad" name="idLocalidad">
                                    <option>Seleccione una localidad</option>
                                </select>
                            </div>
                            <div id="puntos">
                            </div>
                        </div>
                        <div class="row align-items-center">                        
                            <div class="col">
                                <label>Calle</label><br>
                                <input type="text" name="calle">
                            </div>
                            <div class="col-2">
                                <label>Número</label><br>
                                <input type="text" name="nro">
                            </div>
                            <div class="col-2">
                                <label>Piso</label><br>
                                <input type="text" name="piso">
                            </div>
                            <div class="col-2">
                                <label>Depto</label><br>
                                <input type="text" name="depto">
                            </div>                                                
                        </div>            
                        <div id="container-sec">
                            <div class="row align-items-center">
                                <button id="boton" onclick="getPosts()">REGISTRARSE</button>                              
                            </div>
                        </div>
                    </div>                
                </form>                           
            </div>                      
        </div>
        <br><br><br><br><br><br><br>     
        <div id="footer">
            Primer Examen Parcial — Mayo 2021<br>
            Tema 2<br>
            Scovenna Valentina
        </div>                  
    </body>
</html>

<script>
    //Consulta a la api y trae todos los departamentos de la provincia consultada
    var provincia = document.getElementById('idProvincia');
    provincia.addEventListener('change',
        function(){
            var idProvincia = this.options[provincia.selectedIndex].value;           
            $.ajax({
                type: "GET",
                url: "https://apis.datos.gob.ar/georef/api/departamentos?provincia="+idProvincia+"&orden=nombre&max=100",
                success: function (data) {
                    var departamentos = data.departamentos;
                    let template='<option>Seleccione un departamento</option>';
                    departamentos.forEach(depto =>{   
                        template+= "<option value="+depto.id+">"+depto.nombre+"</option>";                        
                    });
                    $('#idDepartamento').html(template);   
                }
            })
        });
    
    //Consulta a la api y trae todas las localidades del departamento consultado
    var departamento = document.getElementById('idDepartamento');
    departamento.addEventListener('change',
        function(){          
            var idDepartamento = this.options[departamento.selectedIndex].value;           
            $.ajax({
                type: "GET",
                url: "https://apis.datos.gob.ar/georef/api/localidades-censales?provincia="+provincia.value+"&departamento="+idDepartamento+"&orden=nombre&max=100",
                success: function (data) {                                        
                    var localidades = data.localidades_censales;                    
                    let template='<option>Seleccione una localidad</option>';
                    localidades.forEach(localidad =>{   
                        template+= "<option value="+localidad.id+">"+localidad.nombre+"</option>";
                    });
                    $('#idLocalidad').html(template);   
                }
            })
        });

    //Consulta a la api de acuerdo a la localidad seleccionada y crea dos input hidden con la latitud y longitud.
    var localidad = document.getElementById('idLocalidad');
    localidad.addEventListener('change',
        function(){          
            var idLocalidad = this.options[localidad.selectedIndex].value;           
            $.ajax({
                type: "GET",
                url: "https://apis.datos.gob.ar/georef/api/localidades-censales?id="+idLocalidad,
                success: function (data) {                                        
                    var puntos = data.localidades_censales[0].centroide;     
                    console.log(puntos.lat);                              
                    let template = "<input type='hidden' value="+puntos.lat+" name='latLocalidad'>"+
                                   "<input type='hidden' value="+puntos.lon+" name='longLocalidad'>";

                    $('#puntos').html(template);   
                }
            })
        });

    var ids = new Array();
    function getPosts(){
        post("ciudadano");
        post("evento"); 
        post("domicilio");  
        permisos(ids);  
    };

    //Función que realiza un post dado un URL e inserta el id del objeto creado en un array global.
    function post(URL) {   
        $.ajax({
            type: "POST",
            url: URL,            
            data: $('#formulario').serialize(),
            async: false,  //para poder devolver los valores hacia la función getPosts                    
            success: function (data) {
                let respuesta = JSON.parse(data);
                ids.push(respuesta['id']);             
            },
            error: function () {
                alert("Error");
            }
        });      
    }

    //Función que genera un permiso con los ids de los objetos ingresados anteriormente.
    function permisos($ids){
        $.ajax({
            type: "POST",
            url: "permiso",            
            data: {ciudadano_id: $ids[0], evento_id: $ids[1], domicilio_id: $ids[2], 
                  fecha:$('#fecha').val(),  _token:'<?php echo e(csrf_token()); ?>'},         
            //La variable _token fue agregada debido a que se generó un error 419 (unknown status)                
            error: function () {
                alert("Error");
            }
        });   
    }

</script>

<!--https://datosgobar.github.io/georef-ar-api/open-api/#/Recursos/get_provincias-->
    <?php /**PATH C:\xampp\htdocs\Parcial_v8\resources\views/form_2.blade.php ENDPATH**/ ?>