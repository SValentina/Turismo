<!DOCTYPE html>

<html lang="en" dir="ltr">
    <head>
        <meta charset="UTF-8">                
        <link rel="stylesheet" href="<?php echo e(asset('/css/comprobante.css')); ?>">                      
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">                                
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>        
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/html2canvas@1.0.0-rc.1/dist/html2canvas.min.js"></script>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            
        </style>
    </head>
    <body>
        <div id="tablecontainer">
            <table>            
                <tbody>
                    <tr>
                        <td colspan="2" id="header">                        
                            <b>Certificado de Circulación</b>
                            <br>Turismo Interno — Según Decreto Nro. 1634/2020
                        </td>                    
                    </tr>
                    <tr>
                        <td style="padding-top: 8%">Código de Permiso</td>
                        <td style="padding-top: 8%" id="codigoPermiso"></td>                    
                    </tr>
                    <tr>
                        <td>Nombre y Apellido</td>
                        <td id="nombre"></td>                    
                    </tr>
                    <tr>
                        <td>Cuil</td>
                        <td id="cuil"></td>                    
                    </tr>
                    <tr>
                        <td>Fecha de generación del permiso</td>
                        <td id="fecha"></td>                    
                    </tr>
                    <tr>
                        <td colspan="2" id="footer">  
                            <!--imagenes codificadas a base 64 para poder convertir el div en imagen-->                           
                            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAQEBAQEBAQEBAQGBgUGBggHBwcHCAwJCQkJCQwTDA4MDA4MExEUEA8QFBEeFxUVFx4iHRsdIiolJSo0MjRERFwBBAQEBAQEBAQEBAYGBQYGCAcHBwcIDAkJCQkJDBMMDgwMDgwTERQQDxAUER4XFRUXHiIdGx0iKiUlKjQyNEREXP/CABEIADIAeAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABQQGAgMHCAH/2gAIAQEAAAAA9/CPy96Ws4AAFX013i/o9fAq1uWYT7NUJzWBz2H0iRmpVOMxVttD+Ly5t8pFp5UcqYaMI/oX0cVmRyy0KrfqS0m7oLzttx8FSGHHxdsd5EcSgMcgAAP/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAQQGAgX/2gAIAQIQAAAA8fydLZDMUdNfBXm5MccgH//EABkBAQADAQEAAAAAAAAAAAAAAAABAwQCBf/aAAgBAxAAAADRn56Dbr8OwFlEkyAf/8QALhAAAgMBAAECAwcDBQAAAAAABAUCAwYBBwATCBIVEBEUFiExQSAiMCMlN1N0/9oACAEBAAESAP059mhPtVInLKj2/dECvvh6GbbUq6LIzRs4zl35oxyLS51nlrIiyFltkZxnPn8/p/iZvLRC4ABh9uv+Xku+mGk6qTkMjBPvtq7CPKlG4OPJppYqK6hr58rj3QQxdOlYAqMDyyAhMq7+ZBsI3RiXCAcDhTz8P+H1uoJSkrloHV1V5I5ZtxZmrdmmr1WQoUMCpIa3VxOl8t3qQs4zWhA8HZZ+LrkNLtSUPfIPtr67uZ3I0v6vRG4Yh4y/SE3KITi0GB5dPyOUHmsbozknfaasiByo2bYwsVVBMGJae0eHrQ55Z4S7WFSPEgMeEeSvMrTbd0a1AgesAioY6R2gEsxmwN0rd4KTWFVQFcXTXXoRB6P904YQNd35au+hFAbYAsQ7p3u38hL3g71FDfnLSGpwwpHO9n5EUoErGk6pq1rvbTsI4H43ITzRTGVwOjZXd2RXrWTytrvKLHLq1c8LsK4n6XgM7NepGpJPAgpU9U1Xi5/Bb9MuZoWd1qaK65LX3c6HxHnTXSba6IdYToM1SrIGHOxMsVzSXbC1jm6CqWnGZVeCy+aRvzWcBc4pKkzAJOz2FSZCq6ZfVaJaRa6GOq8i+I8EpTDEbEUYdmP1kNehp8cQXW+R1enmYjEJaNo3ZNQmoq+uZ50cUuZcsLogwAqY0cpsnOHYz5OEwFHBLukWm3k2/L2EfT4RItcWL67mtnzf61tG8X50lAHoiyjBKwqY10T8YEJejMKV0WfC+9rtv75a/wCbPhz/APY/9ef9b+T/ABZoSaCPaPZcgoB78Nr7NLdJvfHGbZWlpYdGdKp+R2bJR8SaQtTjbdPf3Axh9OdrLsJjs7gN97SWOz2d79ss/NVD/wCFTSoLyulX5luvUTlpo7j8qaXwu1qJ+k4sZi4JYCMT1eu+HE5ZmLdCVDx13kVj9QwwGMIzG0ppz8fI264eYo+GbUBtsg7yw5vCOZhySGN37GeXUtSuGE8vhd2MYykchVnqOpSRfmB5CMY1+LjKOtGolaO0a32/vst3vi3K+RiEZWi4dy9R+I/B2LPCWKV9S/Ja3Jgqb/WBqzcSgN2afeShfB4tEuCqtOyOZhshfIpdkqnI6rqmFtw3jyna93hehC67ir+lVdeZrwq5v2lp7+mPNTMGxpW60PjbSqGyJjo1vRGQUgSeqMv4kCdY16r0Asj8yq6qXerMlnWmtV7+XZktAl9oIk1+HQKti93QFZFThwNSOd/SU5ACl7dts52/9VzfVl87xPlOU87zvyXdTb0/9TNYGBDv71WeOajOd+razQm/f+8aPEuAol2zqCN1nf3sowWLG5zlWYXeq8zm6v0qQLYeuIkn8JwvXUCOXPumlB7z1zJZTlnvRzCqN38WjCUiR7CiEow/T+3+iEIR+f5Yc598v8f/xAA1EAADAAEDBAACBwUJAAAAAAABAgMEABESBRMhMRRRECIyQWFxkiAwgbLBFSNSYmNygoPR/9oACAEBABM/APop9gNNCwLfh89SoVT9IHADU/TmTmZI/Pj+7J2UA6k+4ZnPEeT6GloWYczxHJSB41TqGXj4pdfYGPN+2E+QI86Tbty7YACpsB9UD1rqdjDDxsTD4K9KMP8ANVQNUyG+DpK5KQXHeYbmLMrEP6AGs6lULcygTHFEUpInnt3KEIp0aFDd6HL3k3yA+E1YZWJiSS1kiaW+JRHAQNvqRfdMPHlkVOdBHUO83nDvIhHIzOqVY4nZwjQm7NMEnkktwF9k6kxeRtjPx5SY7Eow2YAjcahWhyZ26Wcni9Q4CFariN69EjUp5QqDj5Bhu70RZNuBuQhOogN3PkCrasyig7Z3UoF3CgH7iNCcYyLybcFttmcAjfWLCF1LeC7qb/YDE6zmVrtWg+2xT6vkDwF2AGsazRya8UHfRSAQVII5A6xct42OAEVTK1B9pdkBB9g66ZlPKFsNWCUx3AAJUcOOqUohp00NkInAIDw82oOWsjN76ocWiuo5KPADqN0092bGkOopSKBf9HjlFZL6UbajlGfwjXZql5U/wN3CAvkFTrJpStcxclyxyHcgly7abMa2Fh5GUz0yrIg9P/euPmASNNlGuIBlP3jSKn0GJ0h2ZXX7xqhAVQfeyoANz89YwkAgoSdhWnFh/A+NYklo7LUgLMzqCp/AnbbWf2wzL6XgkCUQfhsDr/onryT38zdTtsGJKz5PqsK4zsjxSWUAl0R9loNRrKZIbMuC5NtdPBypdN6PjkN2FTFD+GfbgE04cGmInUpHGOzgMF7RCAaJ2TL6PKPPpUuQ9lqE7j5JqLyk1w0qg+bawQMtOldFxrCtQgxQ4J+Qn7TRSqF+m2c1xX42VCv3qAfpjZ59xR6DcdI7Iy9vypVgQQwI8HVcm2TZAj+JW7oAQ+dwBrDy3xnQ5PEP5T/ZrM6hXIQZYmJhmD/a4hfGpVKTpj1B3SqenAJJGnvwiMYu1Nip8Ft2OrZ8jKOOXDkSmTsrEjyRrH6hwk9MBlpJ0VfCtunk6XJWVGgwI25/8jtr+1UcLjFGTZ13+sdm0L88ecrHd2RB4DtvsW0LHsVEAAjmfoOAPf7MJtap/JZgnXV8tMdT+ITHF3/g3E66dg82H5Usx/l0c0xT9Mgo1aruxOqQWn84OlxJD+mvh5/+aONM/wBNLhzWn6gAdF2YAD5bk7fsgfu//8QAKhEAAQQBAgMHBQAAAAAAAAAAAQIDBBEABRITICIhIzEyQUKBUVJxkcH/2gAIAQIBAT8AOuaaJD0Yvd4yCV9JobRZF5qM1jUGESImocFtKqNgg2ciKSqMwpLnEBQnr+7s8eZ/SnzrAktsNGMtNOX4kkUSciRzwtSiqEQqbVvSPRNH1zTVlcJglTajtolvy9nOI0cKdUllAU55zQtX5yJFVHaDW4EAmiQEiiboAZsb9zw+ATlMD3rPwB/ctj6L/Yzo9LHIeb//xAAoEQACAgEBBwMFAAAAAAAAAAABAgMRAAQFEhMgISJRMDGRMkFhcYH/2gAIAQMBAT8ATSTvwgiWZCAosWSTWbU0M+ieNdU3CP2ANg/GKbVaN9Pfmj1G5CoEjCRWtfPTNulZoNLOgk7k+qUdMiNohu/1zvNLJGkTyMyL7AmwMUbgom/5lnxnd4Hznd+M6+l//9k=">                                                                         
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAAAyCAMAAAD/aGCjAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAPnaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIwLTA5LTI1VDEyOjM4OjIzLTAzOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMC0xMC0wNlQxMTo1NTo0MS0wMzowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAyMC0xMC0wNlQxMTo1NTo0MS0wMzowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MDBDQjcxRkQwN0U0MTFFQkE0RjdCNjVFQzhEMzA2NUIiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MDBDQjcxRkUwN0U0MTFFQkE0RjdCNjVFQzhEMzA2NUIiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDowMENCNzFGQjA3RTQxMUVCQTRGN0I2NUVDOEQzMDY1QiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDowMENCNzFGQzA3RTQxMUVCQTRGN0I2NUVDOEQzMDY1QiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PjQ1YQwAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAACXBIWXMAAA7EAAAOxAGVKw4bAAACE1BMVEX///8AgsgAhcoppFcAgcgAhMkAufIAiMsAh8oAhsoAe8UAfcYAfscBAAAAt/IAf8cAtPEAuPIAesUyn9UAsfEHi8wAtfXO6PVxveLj8vr8/f4cGBk5yfYSkM9VsNwhHR51v+Pu9/zq9vv1+/0kolMAd8QalNDV7PZcs97x+v08pNcLjc34/P4jmNJQTU6m1e2z3PBitt+CxOUgoFAyLzAAcsFOrNsrJyjD4/NnuOCKyOfG5fQewvN2dHUxx/UAbsBivINuvOEmo1WTzOnn9PornNTS0dHj4uMRvvXo5+diX18MmEB1vuO43vCPy+k9rGa94PLe3t6enZ0LBgeb0Osbnkx9weRCp9n5+fijoaK87PvY19iCgICPjY6HhIXi8vhHqdmXzelqaGjc7dNWt3oVEBF9envFxMRwwoxJz/cHvPQpxfeXlZarqqpW0fir2O49OTqCypxaVldKsnGv2e/t7e2xr7Bf0/f+//+z6vzX8/ze9v6d5PsyqF6h0+zI8v6/vr6s6PuR4vq1tLRvbG1EQUL19/aR0KX19PTb7ffM6NBDr2xLSEnx8PHq6uqnpaYXnEnLysrh8uap2rve8Ph42vjS8vxn1/mE3fk5ql9kunit7f+r16cArvGS0ar///eKzaLB4Lie1rJrtNxz3P6d5/9/xYq94sq05eCz3sOa1/Hq9u8Aji1u0NeL0ruk2LeZ06+IIZ3vAAAKKklEQVRo3u1Y518aSxeexV23sSwgBCIoasQeLHgjGvSiwd5LLLHF3rtGTWw3RY3pvdfb3/4nvmdmFwRzfRM/vL/Lh3s+wOzMmdlnTnnmzCJ0rNzmOFYRTi5CESxWWcXJ8tSlSAYaTwUMKjasRjLQGEbFqf3Rfj2SgcYxqj3TXpiuRTJQmuQSL7T/ZKqKZJxnjNicNF0/odc/i2SgFpHlKOHH7Um9QR/Rnt9yilTdpQmTIVo3hSLaokV/u+7V66KjDfofIiIUvSUldrsdee0lGy9xy24vmZoqKfFO6nQYZnS0LjJS6apJB2LamNWbrhr00NS/m/r5pyqTzmCIJmII4yYLz1OXj66RwlDxR7rSGJ6IOeVcU6DvbIhaLsPTc4GHbIanChFaVuewcRkDwXUoDas2q7DZDHpk0qcDZr3Jfu3tq9fIbgriDCP7XJmnzh4BVSjyDJsY7iez+lKeoYwZh2rUGVWBBWwxAW0KUHcglEEH5jAioyhanDwvLCtaeoJIf33W+8O7qdmft982vnK77wxdUvxuMIVTUwfFHrVevwyEK86F9Z3meDgpjEajyLOsUEe6MC+L2cp4EovHVdTxUFTQhdgxLCvDHAH+qRQylImbqgdNiuF0Z+wb5z/98vpVY1RyVJT74dukU8TAG+GoyhlWbg/vysA1AZNxhNs4jvFD4zwgYlK+ULMwgFqrODgVb1S+gBDDs3Ib3gW8hHViFw1oYYgTiFq6ClR//eqZ8Vq3OxnDdCe7P+4NfZissod7FK1l8kGrqFIvcuB53pwe2jknsnwmMVibrLTqMXSW12SR8RyMgIlRQxd2IDahdAAvenBPIhhfPA8NGXYJY/W487kCVBf9Bo3faSyLAkl+vzc8vlBbu9A/9OFIOGbJHEd7jpQEfGY5w4k5oZ15smpHNKdlNXGxWI1jocxRQ6QBvM1zIka9peUBtOBHqRTHCknkLQBUSIVMklmqg2Gpc7hz/Z0Jy7vtX+7ciSI4FYu6fQvDtbW7R4A+FViOfxraUySycp1HZMO5II0K2EttFWk52erRcqpaIQ125onvOcbMcpwIVpbJH0gTtIwQAkZOY0aC2vtSDcLHD93JUaFysfHjwRdklgMuNWeFpjdkN4e9Ft4NtqNySWCAmcQGlAVqzFo6C8qxJGAZlr5A8r5QFhvMHJ9JrKyJI7PNGrI5iAljE/4VMcOtqsX7wcXkqLLk5LIAzrJG38Ml35MjQItgscyw6ppmxSKcY5wSSUFmZfmUmJgYs8ixjJkktphHXq2ECJSQAiiJa0kyVX6a4phyYmXODHNSjBqWc95G9QLHnCVRRHjGHqDz943uzeGlxkOk7qXGzaW/hwPNpQMuVSRV5EgswgaUSFLtDDnHAh0yPMeInB8ntgarXQiomXlOA5O0ORmUkFQvc7gXrMxyMAe8QzshlFkNK0CGpkMWyjDFG1z9yfivv2+6y8qIVcG4yVELj7Gfzqy/XC3ZVmmUCadRIBImJjc+7TJYMDP2kFohczhRADFm5qlq5VhNA/wKan4IhDh0muLNvFyIfU5blUJdJnOYNADYLrNcZmF8fCGjUMCkuvbjf9TW1r7y+dybS5D3FxuH75QtDb8eej6rM+n1etN64BRk5bxDnNkC5kaKorAxxKYwGuUs/v7TCrtli5yqhvO7idCoEoSchiNuwvyJafRCUn9/krIGnsPBHAhylkoDvn/2jBRHa7sHB48Xhj8/WXo8vtm44NtcGP8VbVeZyMFl0F1VaNQMi4XwEES9hhhOoNlQU2eLCicF1JhQNfDyspY4e0DmjMvE58CfidhyluCcy3A+KHMAMU8Dj25cn9UTEGu/g00vvv/s8/mGFeUSk0498A0KnWdh1rYOXCDixxdqJs5/ur+/P7GUhixbC7wF3MYcVgQJmEr7iRrM4M1rOKTpOhx+xhgls4yJyALkaQwyR6oAT+f9MMfvERVWBYgTauZfI2fJQvLFTnJm6fTR0QGggenYHTIRZylmf212MKs4rSfkpn14pvopnhUCapjUPSiXYuUtTF4kjDgeZ8uczPFU6M2S6lDbEBM0KRfQO7VnnZTyB7U+krlKVQJuhxiNVl3qpIPi3OoQaDElsHKmSBuDeX8WHnKDnGoMUWO1tHAZlYv0d0EvJ2llERgsz0mLcYG+BidYIlBpxQu0TGq9kmAFX/Xb3n/+vfdw+MnnvSFc/mGQkxOzqy9UjTMJdQmqWPOy8qx1pf2BqculCaXBIqDJam0Pnv3toBY8zHKImsdqHTiM9AarFbLan2C1BsFng9pykENKE+qI6SeDa6afGhrffAhH6NKnVfC7Tj/1pn7g3O1IuR0918eiS8pHm43oA19jctTw3m+nDAZTyXY7Jcri04i5x12qMthflJDmC++nj+PjvoMSuJS8yRMgE3k+ci6chFbsXkLqq96hJ76Df53SVV2NwxXtkbP9iDxw5bseqO2Vwd2Tvri5+A86a7q/ZtcJwqcvdWuv0YTeaxGVb09HavdQ2bU5Wm70jFQqT2MO/FshdX470Plw5WoJfkanvz5P4dNrp/754dSkReCVj3n4NnOMOG6GPk3XnNSgM/OOK190dn/DRLg6T3pn19FElf65rOIkt5k/lhZHYG2HNFKBBm2SNI1GB1GLJC2infwa6Uq+S2ptRmMjko1Yvdkh2VZibS7Jdo/Ma60uhs2t5EtSN3JJ0kyXC1XYpJFmtHhrRLrxFbBJ66te79QPvJHi1c/i9cepuiDC7g0W36huHUO9NjT/AO20ItfMTgHYeqxlpLKy0lGB7vZ2t1ag4nzQvzdSjYoXq23VqIDE9eBN9MiBOqUuVIkcxWh3f7BvRXqEehzI0YJ6b32jW3LSGIEiBcyxNHoXPF9dbOu6OYrQvq26oBntO6rzK12OgoLWnZpeiFeANz/mmsa2hGDsGskvsNXsAALYAPRJWPb7FqF9A28E5T+q6YP9SAhitWfwBF+fzhllKByPHW+R7sNvQberB6He+X0w5JWCzoL9/DE8WPAIFO4Cpv38FoSKXdDVgyFhBLu2fazRgrF1jeLQ7iJAJXQLttdz974NrNByonBvpwTN8aOLkmuwoHVlTLrpGukck0ZrpO5mG+ptHa1xVOOorBlFlbbYK1LxLRuu+bqlmuLW7lst2OGQewV4ib75SmnxZjFqnR9dvC+hHanY1QpJBvFbccLMbJv7H4MVfT04bZv7usD5Mz3TsagSnndGu1DnDEC70YxW4LmiZ0ZRr+zrrUYPVlAlTpSuatx1/wG619vbDLj7KrBudw8sVQE+mY6wY0aphMOf/5ITSWxWov90UlJiViSC83va2tM6zppl53dEvlfFycSVn6tr88T+6QizmoriU0QCzsmkxJzLTShqm6v3WFJv9xNJtXhythra0wrzsj1JfxbInMKzRjCaOSa3aM6SGKFx2NZBfy/HFLZZIjlbzsczzOUGS4TndH1aBr6oRbgknt9K/b8t/l/bJNaNBnqGfgAAAABJRU5ErkJggg==">                        
                        </td>
                    </tr>
                </tbody>
            </table>             
        </div>      
        <button id="boton">Descargar Comprobante</button>                   
    </body>

    
    <script>        
        //Script para armar el comprobante con los datos de localStorage
        $(function () {            
            var fecha = new Date();
            var mes = ("0" + (fecha.getMonth() + 1)).slice(-2);                        
            $('#codigoPermiso').html("<b>"+localStorage.getItem("codigoPermiso")+"</b>")            
            $('#nombre').html("<b>"+localStorage.getItem("nombre")+" "+localStorage.getItem("apellido")+"</b>");
            var cuil = localStorage.getItem("cuil");
            var cuilGuiones = cuil.slice(0,2)+"-"+cuil.slice(2,cuil.length-1)+"-"+cuil[cuil.length-1];
            $('#cuil').html("<b>"+cuilGuiones+"</b>");
            $('#fecha').html("<b>"+fecha.getDate()+"-"+mes+"-"+fecha.getFullYear()+"</b>");            
        });

        //https://parzibyte.me/blog/2019/07/11/html-a-imagen-html2canvas-screenshot-de-pagina-web/
        //Definimos el botón para escuchar su click
        const $boton = document.querySelector("#boton"), // El botón que desencadena
        $objetivo = document.getElementById("tablecontainer"); // A qué le tomamos la fotocanvas
        // Nota: no necesitamos contenedor, pues vamos a descargarla

        // Agregar el listener al botón
        $boton.addEventListener("click", () => {
            html2canvas($objetivo) // Llamar a html2canvas y pasarle el elemento
                .then(canvas => {
                    // Cuando se resuelva la promesa traerá el canvas
                    // Crear un elemento <a>
                    let enlace = document.createElement("a");
                    enlace.download = "Comprobante.png";
                    // Convertir la imagen a Base64
                    enlace.href = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream");
                    // Hacer click en él
                    enlace.click();
                });
            });

    </script>
</html><?php /**PATH C:\xampp\htdocs\Parcial_v8\resources\views/comprobante.blade.php ENDPATH**/ ?>