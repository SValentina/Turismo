<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
    <head>
        <meta charset="UTF-8">                
        <link rel="stylesheet" href="<?php echo e(asset('/css/admin.css')); ?>">               
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">                
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>     
        <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>

    <body>
        <nav class="navbar">
            <div class="container-fluid">
              <p class="navbar-brand">
                <img src="https://th.bing.com/th/id/R4d19ffada6f4573454c7b1a77c01a10d?rik=kYVXD1G%2b2d3Akg&pid=ImgRaw" alt="logo-admin" width="40" height="40">
                <b>Admin</b>
              </p>
            </div>
        </nav>
        <div class="container">
            <div class="container" id="container-row">
                <div class="row">
                    <div class="col-sm-8">
                        <div class="card" id="select">
                            <p style="font-size: 22px;">Ingrese fecha y evento a buscar</p>
                            <div class="row" id="select-row">
                                <?php echo csrf_field(); ?> 
                                <div class="col-sm-4">
                                    <input id="fecha_evento" type="date">
                                </div>                                                   
                                <div class="col-sm-6">
                                    <select id="evento_id" name="evento_id">
                                        <option>Parque Luro</option>
                                    </select>
                                </div>
                                <div class="col-sm">
                                    <button onclick="buscar()"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="card" id="datos1">
                        <?php ($contador = 0); ?>
                        
                        <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($contador++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php ($contador2 = 0); ?>
                        <?php $__currentLoopData = $hoy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($contador2++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            <p id="num">#<?php echo e($contador); ?></p>
                            <p id="sub">Permisos generados</p>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="card" id="datos2">
                            <p id="num">#<?php echo e($contador2); ?></p>
                            <p id="sub">Permisos generados hoy</p>
                        </div>
                    </div>   
                </div>
            </div>
            <div class="container" id="container-row">
                <div class="row">
                    <div class="col-sm" id="contenedor-mapa">
                        
                    </div>
                </div>
            </div>
        </div>
    </body>

    <script src="<?php echo e(asset('/js/admin.js')); ?>" type="text/javascript"></script>
</html>
<?php /**PATH C:\xampp\htdocs\Parcial_v8\resources\views/admin.blade.php ENDPATH**/ ?>